from flask import Flask, render_template,redirect, url_for, request, session, send_from_directory, jsonify, make_response
from passlib.hash import sha256_crypt
from MySQLdb import escape_string as thwart
from dbconnect import connection
from functools import wraps
from werkzeug import secure_filename
from werkzeug.exceptions import HTTPException
from authlib.flask.client import OAuth
from six.moves.urllib.parse import urlencode

import gc, os, json, constants, ssl
import urllib.request as logo

context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
context.verify_mode = ssl.CERT_NONE
context.load_cert_chain("certificate.crt", "privateKey.key")


app = Flask(__name__)
app.config['SECRET_KEY'] = constants.SECRET_KEY
app.config['UPLOAD_FOLDER']=''

ALLOWED_EXTENSIONS=['png']

AUTH0_CALLBACK_URL = "https://tps.com:4444/callback"
AUTH0_CLIENT_ID = "@!476B.F204.1952.447C!0001!F388.20DD!0008!208E.CF27.7AC6.8F12"
AUTH0_CLIENT_SECRET = "0veNJAfALYIlwvawJlDMTn5Y"
AUTH0_DOMAIN = "iam.centroxy.com"

AUTH0_BASE_URL = 'https://' + AUTH0_DOMAIN
AUTH0_AUDIENCE = ""
if AUTH0_AUDIENCE is '':
    AUTH0_AUDIENCE = AUTH0_BASE_URL + '/oxauth/restv1/userinfo'

oauth = OAuth(app)

auth0 = oauth.register(
    'auth0',
    client_id=AUTH0_CLIENT_ID,
    client_secret=AUTH0_CLIENT_SECRET,
    api_base_url=AUTH0_BASE_URL,
    access_token_url=AUTH0_BASE_URL + '/oxauth/restv1/token',
    authorize_url=AUTH0_BASE_URL + '/oxauth/restv1/authorize',
    client_kwargs={
        'scope': 'openid profile',
    },
)


def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if constants.PROFILE_KEY not in session:
            return redirect('/login')
        return f(*args, **kwargs)

    return decorated


@app.route('/gluulogin')
def gluulogin():
    return auth0.authorize_redirect(redirect_uri=AUTH0_CALLBACK_URL, audience=AUTH0_AUDIENCE)

@app.route('/callback')
def callback_handling():
    print(0)
    auth0.authorize_access_token(verify=False)
    print(1)
    print(auth0)
    print(auth0.get)
    resp = auth0.get('oxauth/restv1/userinfo', verify=False)
    print(2)
    userinfo = resp.json()
    # print(userinfo)
    session[constants.JWT_PAYLOAD] = userinfo
    session[constants.PROFILE_KEY] = {
        'user_id': userinfo['sub'],
        'name': userinfo['name'],
        
    }
    cursor, conn=connection()
    username=userinfo['name']
    if(bool(username.strip())):
        x=cursor.execute("select * from users where username='{0}'".format(ddecode(thwart(username))))
        if(x>0):
            session['user_type']='user'
            session['logged_in']=True
            data=cursor.fetchall()
            session["user_id"]=data[0][0]
            session['username']=username
            return redirect('/dashboard')
    else:
        return render_template("register.html",error="Username can't be empty")
    cursor.execute("insert into users (username,user_type) values ('{0}','user')".format(username))
    conn.commit()
    session["user_type"]="user"
    cursor.execute("select id from users where username='{0}'".format(username))
    data=cursor.fetchall()[0][0]
    session["user_id"]=data
    session['logged_in']=True
    session['username']=username
    return redirect('/dashboard')

@app.route('/gluulogout')
def gluulogout():
    session.clear()
    params = {'post_logout_redirect_uri': "https://tps.com:4444",
              'client_id': AUTH0_CLIENT_ID}
    print(auth0.api_base_url)
    return redirect(auth0.api_base_url + '/oxauth/restv1/end_session?' + urlencode(params))



# @app.route('/dashboard')
# @requires_auth
# def dashboard():
#     return render_template('dashboard.html',
#                            userinfo=session[constants.PROFILE_KEY],
#                            userinfo_pretty=json.dumps(session[constants.JWT_PAYLOAD], indent=4))


def ddecode(data):
    return data.decode(encoding='utf-8')

@app.route('/test/')
def test():
    print('test')
    return render_template('test.html')

@app.route('/app/<string:app_name>')
def add_app_u(app_name):
    print(app_name)
    cursor, conn=connection()
    cursor.execute("select * from apps where name='{0}'".format(ddecode(thwart(app_name))))
    data=cursor.fetchall()
    print(data)
    print(session['user_id'])
    #print(ddecode(thwart(session['user_id'])))
    #print(ddecode(thwart(data[0][0])))
    cursor.execute("insert into users_apps_dir (id, user_id, app_id) values (NULL, '{0}','{1}')".format(str(session['user_id']),str(data[0][0])))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for("dashboard"))

@app.route('/dashboard/search/')
def search():
    print(1)
    string= request.args['searchText']
    cursor, conn=connection()
    cursor.execute("select name from apps WHERE name like '%{0}%'".format(ddecode(thwart(string))))
    names=cursor.fetchall()
    print(names)
    print(json.dumps(names))
    return json.dumps(names)



def login_required(f):
    @wraps(f)
    def wrap(*args,**kwargs):
        if 'logged_in' in session:
            return f(*args,**kwargs)
        else:
            return render_template("login.html",error="")
    return wrap

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login/', methods=['GET','POST'])
def login():
    try:
        if 'logged_in' in session:
            return redirect(url_for("dashboard"))
        if request.method=="POST":
            username=request.form['username']
            if(bool(username.strip())):
                cursor,conn=connection()
                data=cursor.execute("select * from users where username='{0}'".format(ddecode(thwart(username))))
                if(int(data)==0):
                    return render_template("login.html",error='Invalid Credentials!!')
                data=cursor.fetchall()
                print(data)
                #cursor.execute("select * from users where username='{0}'".format(ddecode(thwart(username))))
                if sha256_crypt.verify(request.form['password'],data[0][6]):
                    session['logged_in']=True
                    session['username']=username
                    session['user_id']=data[0][0]
                    session['user_type']=data[0][7]
                    cursor.close()
                    conn.close()
                    return redirect(url_for("dashboard"))
                else:
                    cursor.close()
                    conn.close()
                    return render_template("login.html",error="Invalid Credentials")
            else:
                return render_template("login.html",error="Username can't be empty")
        gc.collect()
        return render_template("login.html")
    except Exception as e:
        print(str(e))

@app.route('/admin/')
@login_required
def admin():
    if(session["user_type"]=="user"):
        return redirect(url_for("dashboard"))
    cursor, conn=connection()
    cursor.execute("select * from apps")
    apps=cursor.fetchall()
    print(apps)
    return render_template('admin_dashboard.html',apps=apps)


@app.route('/save/app/', methods=['POST'])
def save_app_creds():
    try:
        if request.method=='POST':
            app_id=request.form['app_id']
            app_username=request.form['app_username']
            app_password=request.form['app_password']
            print(app_id, app_username, app_password)
            cursor, conn=connection()
            cursor.execute("insert into users_apps_cred (id, user_id, app_id, username, password) values (NULL, '{0}', '{1}' ,'{2}' ,'{3}')".format(str(session['user_id']),ddecode(thwart(app_id)),ddecode(thwart(app_username)),ddecode(thwart(app_password))))
            conn.commit()
            cursor.close()
            conn.close()

            return redirect(url_for('dashboard'))
        return redirect(url_for('dashboard'))
    except Exception as e:
        return redirect(url_for('dashboard'))


@app.route('/add/', methods=['POST'])
def add_app():
    try:
        if request.method=='POST':
            cursor, conn=connection()
            
            app_name=request.form['app_name']
            login_url=request.form['login_url']
            logo_img=request.form['logo_img']
            logo_type=logo_img.split(".")[-1]
            logo.urlretrieve(logo_img,"./static/img/{0}.{1}".format(app_name,logo_type))
            logo_img="/static/img/{0}.{1}".format(app_name,logo_type)
            # print(type(app_name),app_name)
            # print(type(login_url), login_url)
            # print(type(logo_img),logo_img)
            # print(type(thwart(logo_img)))
            if(bool(app_name.strip()) and bool(login_url.strip()) and bool(logo_img.strip())):
                cursor.execute("insert into apps (id, name, url, logo) values (NULL, '{0}','{1}','{2}')".format(ddecode(thwart(app_name)), ddecode(thwart(login_url)), ddecode(thwart(logo_img))))
                conn.commit()
                cursor.close()
                conn.close()
                return redirect(url_for("admin"))
        else:
            return redirect(url_for("admin"))
    except Exception as e:
        return redirect(url_for("admin"))

@app.route('/dashboard/')
@login_required
def dashboard():
    print(session)
    if(session["user_type"]=="admin"):
        return redirect(url_for("admin"))
    cursor, conn=connection()
    cursor.execute("select * from apps left join users_apps_dir on apps.id = users_apps_dir.app_id where users_apps_dir.user_id='{0}'".format(str(session['user_id'])))
    apps=cursor.fetchall()
    print(apps)
    cursor.execute("select * from users_apps_cred where user_id='{0}'".format(str(session['user_id'])))
    cred=cursor.fetchall()
    print(cred)
    set_app=[]
    for i in cred:
        set_app.append(i[2])
    print(set_app)
    resp = make_response(render_template('dashboard.html', apps=apps, set_app=set_app))
    resp.set_cookie('_ajax_id', 'cookie')
    return resp
    #return render_template('dashboard.html', apps=apps)


@app.route('/register/', methods=['GET','POST'])
def register():
    try:
        if 'logged_in' in session:
            return redirect(url_for("dashboard"))
        else:
            if request.method=="POST":
                cursor, conn=connection()
                username=request.form['username']
                if(bool(username.strip())):
                    x=cursor.execute("select * from users where username='{0}'".format(ddecode(thwart(username))))
                    if(x>0):
                        cursor.close()
                        conn.close()
                        return render_template("register.html",error="Username not available")
                else:
                    return render_template("register.html",error="Username can't be empty")

                email=request.form['email']
                if(bool(email.strip())):
                    x=cursor.execute("select * from users where email='{0}'".format(ddecode(thwart(email))))
                    if(x>0):
                        cursor.close()
                        conn.close()
                        return render_template("register.html",error="Emaild exists. Login Instead.")
                else:
                    return render_template("register.html",error="Email-id can't be empty")
                user_type='user'
                fname=request.form['fname']
                lname=request.form['lname']
                ph_no=request.form['telephone']
                password=request.form['password']
                c_password=request.form['confirm']
                if(password==c_password):
                    del c_password
                    password=sha256_crypt.hash((password))
                    cursor.execute("insert into users (username,email,password,user_type,fname,lname,mobile) values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}')".format(ddecode(thwart(username)),ddecode(thwart(email)),ddecode(thwart(password)),ddecode(thwart(user_type)),ddecode(thwart(fname)),ddecode(thwart(lname)),ddecode(thwart(ph_no))))
                    conn.commit()
                    cursor.close()
                    conn.close()
                    gc.collect()
                    return redirect(url_for('login'))
                else:
                    cursor.close()
                    conn.close()
                    return render_template("register.html",error="Passwords should match.")
        return render_template('register.html')

    except Exception as e:
        return render_template('register.html')


@app.route('/logout/')
def logout():
    resp =  make_response(redirect(url_for("gluulogout")))
    resp.delete_cookie('_ajax_id')
    session.clear()
    gc.collect()
    return resp

@app.errorhandler(404)
def page_n_found(e):
	return render_template("404.html")

if __name__=="__main__":
    app.jinja_env.auto_reload = True
    app.config['TEMPLATES_AUTO_RELOAD'] = True
    app.run(debug=True, host='tps.com',port=4444,ssl_context=context)
    #print(dir(app))