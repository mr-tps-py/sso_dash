import MySQLdb
def connection():
    conn = MySQLdb.connect(host="localhost",user="root",passwd="",db="tps_sso_users")
    cursor=conn.cursor()
    return cursor,conn